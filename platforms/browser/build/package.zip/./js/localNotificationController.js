

//Local notification for app running on foreground and background

function addNotification(offerid, storename){
                                                   
                
}


    