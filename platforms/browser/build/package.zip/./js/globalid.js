var globalID = {
		tripPlanuuid: "undefined",
		offeruuid: "undefined",
		geofenceuuid: "undefined",
//        partneruuid: = "undefined",
//        couponImage: = "undefined",
        couponEncode: "undefined"
};
window.globalURL = "http://xixixhalu-test.apigee.net/proxy/tripPlanner";
window.globalID = globalID;